function activePhoto(element) {
  const sound = document.getElementById("clickSound");

  sound.pause();
  sound.currentTime = 0;
  sound.play();

  document.querySelectorAll(".photo").forEach((photo) => {
    photo.classList.remove("active");
  });

  element.classList.add("active");

  document.getElementById("thanksText").style.opacity = "1";
}
